OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Guardado",
    "Error" : "Erro",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Tema Breeze Dark para a Nextcloud, baseado no mesmo tema do KDE",
    "Save" : "Guardar",
    "Breeze Dark theme" : "Tema Breeze Dark"
},
"nplurals=2; plural=(n != 1);");
