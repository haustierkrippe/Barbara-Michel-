OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Đã lưu",
    "Error" : "Lỗi",
    "Breeze Dark" : "Breeze Dark",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Chủ đề Breeze Dark cho Nextcloud, dựa trên chủ đề bởi KDE",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "Một chủ đề tối dựa trên Breeze Dark bởi dự án KDE. Hãy tải lại trang để áp dụng thay đổi.",
    "Enable Breeze Dark theme by default" : "Bật chủ đề Breeze Dark theo mặc định",
    "This setting will allow you to choose if the login page should be themed when the theme is enabled by default." : "Cài đặt này sẽ cho phép bạn chọn xem trang đăng nhập có nên được đặt chủ đề hay không khi chủ đề được bật theo mặc định.",
    "Theme the login page" : "Đặt chủ đề cho trang đăng nhập",
    "Save" : "Lưu",
    "A Breeze Dark theme for Nextcloud." : "Chủ đề Breeze Dark cho Nextcloud.",
    "Breeze Dark theme" : "Chủ đề Breeze Dark",
    "Enable Breeze Dark theme" : "Bật chủ đề Breeze Dark"
},
"nplurals=1; plural=0;");
