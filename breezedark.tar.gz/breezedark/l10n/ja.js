OC.L10N.register(
    "breezedark",
    {
    "Saved" : "保存しました。",
    "Error" : "エラー",
    "Breeze Dark" : "Breeze Dark",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "ダークテーマはKDEプロジェクトのブリーズダークです。変更反映のためページをリフレッシュして下さい。",
    "Save" : "保存",
    "A Breeze Dark theme for Nextcloud." : "NextcloudのBreeze Darkテーマ。",
    "Breeze Dark theme" : "Breeze Dark テーマ",
    "Enable Breeze Dark theme" : "Breeze Darkテーマを有効化"
},
"nplurals=1; plural=0;");
