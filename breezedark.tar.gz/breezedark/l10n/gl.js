OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Gardado",
    "Error" : "Erro",
    "Breeze Dark" : "Breeze Dark",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Tema Breeze Dark para Nextcloud, baseado no tema de KDE",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "Un tema escuro baseado no Breeze Dark do proxecto KDE. Actualice a páxina para que os cambios teñan efecto.",
    "Enable Breeze Dark theme by default" : "Activar o tema Breeze Dark de xeito predeterminado",
    "This setting will allow you to choose if the login page should be themed when the theme is enabled by default." : "Este axuste permitiralle escoller se a páxina de acceso debería ser tematizada cando o tema está activado como predeterminado.",
    "Theme the login page" : "Tema da páxina de acceso",
    "Custom Styling" : "Estilo personalizado",
    "Insert custom styling here …" : "Insira o estilo personalizado aquí…",
    "Save" : "Gardar",
    "A Breeze Dark theme for Nextcloud." : "Un tema Breeze Dark para Nextcloud.",
    "Breeze Dark theme" : "Tema Breeze Dark",
    "Enable Breeze Dark theme" : "Activar o tema Breeze Dark"
},
"nplurals=2; plural=(n != 1);");
