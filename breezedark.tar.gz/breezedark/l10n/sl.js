OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Shranjeno",
    "Error" : "Napaka",
    "Breeze Dark" : "Temna tema Breeze",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Temna tema Breeze za Nextcloud, zasnovana po predlogi teme KDE.",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "Temna tema, zasnovana na temi Breeze Dark, projekta KDE. Za uveljavitev sprememb je treba stran osvežiti.",
    "Enable Breeze Dark theme by default" : "Privzeto omogoči temno temo Breeze",
    "This setting will allow you to choose if the login page should be themed when the theme is enabled by default." : "Nastavitev določa prilagoditev prijavne strani, če je tema omogočena privzeto.",
    "Theme the login page" : "Uporabi temo na prijavni strani",
    "Custom Styling" : "Slog po meri",
    "Insert custom styling here …" : "Vpišite slog po meri ...",
    "Save" : "Shrani",
    "A Breeze Dark theme for Nextcloud." : "Temna tema Breeze za Nextcloud",
    "Breeze Dark theme" : "Temna tema Breeze",
    "Enable Breeze Dark theme" : "Omogoči temno temo Breeze"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
