OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Sarvadu",
    "Error" : "Errore",
    "Breeze Dark" : "Breeze Dark",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Tema Breeze Dark pro Nextcloud, basadu subra de su tema de KDE",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "Tema iscuru basadu subra de Breeze Dark dae su progetu KDE. Atualiza sa pàgina pro chi is modìficas tèngiant efetu.",
    "Enable Breeze Dark theme by default" : "Ativa su tema Breeze Dark comente predefinidu",
    "This setting will allow you to choose if the login page should be themed when the theme is enabled by default." : "Custa cunfiguratzione t'at a permìtere de seberare si sa pàgina de intrada depet èssere ammustrada cun su tema predefinidu ativu.",
    "Theme the login page" : "Imprea su tema pro sa pàgina de intrada",
    "Custom Styling" : "Istile personalizadu",
    "Insert custom styling here …" : "Inserta s'istile personalizadu inoghe...",
    "Save" : "Sarva",
    "A Breeze Dark theme for Nextcloud." : "Tema Breeze Dark pro Nextcloud.",
    "Breeze Dark theme" : "Tema Breeze Dark",
    "Enable Breeze Dark theme" : "Ativa su tema Breeze Dark"
},
"nplurals=2; plural=(n != 1);");
