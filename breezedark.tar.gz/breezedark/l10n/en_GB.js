OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Saved",
    "Error" : "Error",
    "Breeze Dark" : "Breeze Dark",
    "Breeze Dark theme for Nextcloud, based on the theme by KDE" : "Breeze Dark theme for Nextcloud, based on the theme by KDE",
    "A Dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect." : "A dark theme based on Breeze Dark by the KDE project. Please refresh the page for changes to take effect.",
    "Enable Breeze Dark theme by default" : "Enable the Breeze Dark theme by default",
    "This setting will allow you to choose if the login page should be themed when the theme is enabled by default." : "This setting will allow you to choose if the login page should be themed when the theme is enabled by default.",
    "Theme the login page" : "Theme the login page",
    "Custom Styling" : "Custom styling",
    "Insert custom styling here …" : "Insert custom styling here …",
    "Save" : "Save",
    "A Breeze Dark theme for Nextcloud." : "A Breeze Dark theme for Nextcloud.",
    "Breeze Dark theme" : "Breeze Dark theme",
    "Enable Breeze Dark theme" : "Enable Breeze Dark theme"
},
"nplurals=2; plural=(n != 1);");
