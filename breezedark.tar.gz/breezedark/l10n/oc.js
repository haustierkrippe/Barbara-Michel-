OC.L10N.register(
    "breezedark",
    {
    "Saved" : "Enregistrat",
    "Error" : "Error",
    "Breeze Dark" : "Breeze Dark",
    "Theme the login page" : "Tèma per la pagina de connexion",
    "Custom Styling" : "Estil personalizat",
    "Save" : "Enregistrar",
    "A Breeze Dark theme for Nextcloud." : "Un tèma Breeze Dark per Nextcloud.",
    "Breeze Dark theme" : "Tèma Breeze Dark",
    "Enable Breeze Dark theme" : "Activar lo tèma Breeze Dark"
},
"nplurals=2; plural=(n > 1);");
